import React from 'react'

export default function RouteCard({ route, onBuy }){
  return (
    <div className="bg-white p-4 rounded-lg shadow">
      <h2 className="font-semibold text-lg">{route.from} → {route.to}</h2>
      <p className="text-sm text-gray-600">{route.duration} • Seats left: {route.remaining}</p>
      <div className="mt-3 flex items-center justify-between">
        <div>
          <div className="text-xl font-bold">RWF {route.price.toLocaleString()}</div>
        </div>
        <div>
          <button onClick={onBuy} className="px-4 py-2 bg-indigo-600 text-white rounded">Buy</button>
        </div>
      </div>
    </div>
  )
}
