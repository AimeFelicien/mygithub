import React, { useState } from 'react'

export default function PurchaseModal({ route, onClose, onSubmit }){
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [quantity, setQuantity] = useState(1)

  function submit(e){
    e.preventDefault()
    onSubmit({ routeId: route.id, name, phone, quantity })
  }

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black/30">
      <div className="bg-white p-6 rounded max-w-md w-full">
        <h3 className="text-xl font-semibold">Buy tickets — {route.from} → {route.to}</h3>
        <form className="mt-4" onSubmit={submit}>
          <label className="block text-sm">Name</label>
          <input required value={name} onChange={e=>setName(e.target.value)} className="w-full p-2 border rounded" />

          <label className="block text-sm mt-2">Phone (mobile)</label>
          <input required value={phone} onChange={e=>setPhone(e.target.value)} className="w-full p-2 border rounded" />

          <label className="block text-sm mt-2">Quantity</label>
          <input required min={1} max={route.remaining} type="number" value={quantity} onChange={e=>setQuantity(Number(e.target.value))} className="w-24 p-2 border rounded" />

          <div className="mt-4 flex justify-between">
            <button type="button" onClick={onClose} className="px-4 py-2 border rounded">Cancel</button>
            <button type="submit" className="px-4 py-2 bg-green-600 text-white rounded">Pay RWF {(route.price * quantity).toLocaleString()}</button>
          </div>
        </form>
      </div>
    </div>
  )
}
