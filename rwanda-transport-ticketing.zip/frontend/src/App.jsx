import React, { useEffect, useState } from 'react'
import axios from 'axios'
import RouteCard from './components/RouteCard'
import PurchaseModal from './components/PurchaseModal'

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000'

export default function App(){
  const [routes, setRoutes] = useState([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState(null)
  const [success, setSuccess] = useState(null)

  useEffect(()=>{ fetchRoutes() },[])

  async function fetchRoutes(){
    setLoading(true)
    try{
      const res = await axios.get(`${API_BASE}/api/routes`)
      setRoutes(res.data)
    }catch(err){ console.error(err) }finally{ setLoading(false) }
  }

  async function handlePurchase(payload){
    try{
      const res = await axios.post(`${API_BASE}/api/purchase`, payload)
      setSuccess(res.data.ticket)
      setSelected(null)
      fetchRoutes()
    }catch(err){
      alert(err?.response?.data?.error || 'Purchase failed')
    }
  }

  return (
    <div className="min-h-screen p-6">
      <header className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-2">Rwanda Transport Tickets</h1>
        <p className="text-sm text-gray-600 mb-6">Buy bus/minibus tickets across Rwanda (demo). Prices in RWF.</p>
      </header>

      <main className="max-w-4xl mx-auto grid grid-cols-1 sm:grid-cols-2 gap-4">
        {loading ? <div>Loading routes...</div> : routes.map(r => (
          <RouteCard key={r.id} route={r} onBuy={() => setSelected(r)} />
        ))}
      </main>

      {selected && <PurchaseModal route={selected} onClose={()=>setSelected(null)} onSubmit={handlePurchase} />}

      {success && (
        <div className="fixed bottom-6 right-6 bg-white p-4 shadow rounded">
          <div className="text-sm">Purchase successful!</div>
          <div className="text-xs text-gray-600">Ticket ID: {success.id}</div>
          <div className="text-xs text-gray-600">Route: {success.routeFrom} → {success.routeTo}</div>
        </div>
      )}
    </div>
  )
}
