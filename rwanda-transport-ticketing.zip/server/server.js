const express = require('express');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 4000;

// Sample routes across Rwanda (demo). Prices in RWF.
const routes = [
  { id: 'r_kg_rv', from: 'Kigali', to: 'Rubavu', duration: '3h', price: 5000, capacity: 40 },
  { id: 'r_kg_hu', from: 'Kigali', to: 'Huye', duration: '2.5h', price: 4000, capacity: 35 },
  { id: 'r_kg_ak', from: 'Kigali', to: 'Akagera', duration: '4h', price: 7000, capacity: 30 },
  { id: 'r_kg_gs', from: 'Kigali', to: 'Gisenyi', duration: '3.2h', price: 5200, capacity: 40 },
  { id: 'r_kg_ks', from: 'Kigali', to: 'Kayonza', duration: '2h', price: 3500, capacity: 45 }
];

let purchases = []; // in-memory purchases

app.get('/api/routes', (req, res) => {
  const withRemaining = routes.map(r => {
    const sold = purchases.filter(p => p.routeId === r.id).reduce((a,b)=>a+b.quantity,0);
    return { ...r, remaining: Math.max(0, r.capacity - sold) };
  });
  res.json(withRemaining);
});

app.post('/api/purchase', (req, res) => {
  // body: { routeId, name, phone, quantity }
  const { routeId, name, phone, quantity } = req.body;
  if (!routeId || !name || !phone || !quantity) return res.status(400).json({ error: 'missing fields' });

  const route = routes.find(r => r.id === routeId);
  if (!route) return res.status(404).json({ error: 'route not found' });

  const sold = purchases.filter(p => p.routeId === routeId).reduce((a,b)=>a+b.quantity,0);
  const remaining = route.capacity - sold;
  if (quantity > remaining) return res.status(400).json({ error: 'not enough seats' });

  const ticketId = uuidv4();
  const total = route.price * quantity;
  const purchase = {
    id: ticketId,
    routeId,
    routeFrom: route.from,
    routeTo: route.to,
    name,
    phone,
    quantity,
    total,
    purchasedAt: new Date().toISOString()
  };

  purchases.push(purchase);

  // simulate sending ticket by returning payload
  res.json({ success: true, ticket: purchase });
});

app.get('/api/purchases', (req, res) => {
  res.json(purchases);
});

app.listen(PORT, () => {
  console.log(`Rwanda transport ticket server running on http://localhost:${PORT}`);
});
