# Rwanda Transport Ticketing — Demo App

This is a minimal demo web app for purchasing transport tickets across Rwanda (cities and routes).
It's built as a frontend (React + Vite) and a backend (Node + Express). Payment is simulated.

## Contents
- server/ : Node + Express API that serves routes and handles purchases (in-memory).
- frontend/ : React + Vite frontend to list routes and buy tickets.

## How to use locally
1. Unzip and `cd rwanda-transport-ticketing`
2. Start backend:
   ```
   cd server
   npm install
   npm start
   ```
3. Start frontend:
   ```
   cd ../frontend
   npm install
   npm run dev
   ```
4. Open the frontend (usually at http://localhost:5173)

## Deploy notes
- Replace in-memory storage with a proper database (SQLite/Postgres).
- Integrate a real payment gateway (Stripe/MTN/Rwf mobile money) before production.
- Configure CORS and secure environment variables.
